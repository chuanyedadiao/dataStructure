#include<stdio.h>
#include<time.h> 
#include<stdlib.h>
#include<windows.h>
#include<math.h>

typedef struct node
{
	int num;
	struct node *next;
}Node,*NodeList;

typedef struct key
{
	int keynum;
	Node *next;
}Key;

void output(NodeList L)
{
	Node *p;
	p=L->next;
	while(p)
	{
		printf("%d ",p->num);
		p=p->next;
	}
	
}

NodeList InitNodelist(NodeList L)
{
	L=(NodeList)malloc(sizeof(Node));
	L->next=NULL;
	return L;
}

NodeList CreateNodelist(NodeList L,int Randnum[])
{
	int i=0;
	Node *p,*q;
	q=L;
	while(i<20)
	{
		p=(Node*)malloc(sizeof(Node));
		p->num=Randnum[i];
		i++;
		q->next=p;
		q=p;
	}
	q->next=NULL;
	return L;
}

int High(int Randnum[])
{
	int i=0;
	int max=0;
	int flag,tag=0;
	while(i<20)
	{
		flag=Randnum[i];
		while(flag!=0)
		{
			tag++;
			flag=flag/10;
		}
		if(tag>max)
		{
			max=tag;
		}
		tag=0;
		i++;
	}
	return max;
}

NodeList Distribute(NodeList L,Key f[],Key e[],int i)
{
	Node *p1,*p2,*q1,*q2;
	p1=L->next;
	p2=p1->next;
	int flag;
	while(p1)
	{
		if(i!=0)
		    flag=(int)((p1->num)/(pow(10,i)))%10;
		else flag=(p1->num)%10;
		q2=f[flag].next;
		if(q2==NULL)
		{
			p1->next=q2;
			f[flag].next=p1;
		}
		else 
		{
			while(q2)
			{
				q1=q2;
				q2=q1->next;
			}
			p1->next=q2;
			q1->next=p1;
		}
		e[flag].next=p1;
		p1=p2;
		if(p2!=NULL)
		{
			p2=p1->next;
		}
	}
	L->next=NULL;
	return L;
}

NodeList Collect(NodeList L,Key f[],Key e[])
{
	int i;
	Node *p1,*p2,*q;
	q=L; 
	for(i=0;i<10;i++)
	{
		p1=f[i].next;
		if(p1==NULL)
		    continue;
		q->next=p1;
		p2=p1->next;
		while(p2)
		{
			p1=p2;
			p2=p1->next;
		}
		q=p1;
		f[i].next=NULL;
		e[i].next=NULL;
	}
	q->next=NULL;
	return L;
}

double RadixSort(int Randnum[])
{
	time_t time_start;
	time_t time_over;
	Key e[10];
	Key f[10];
	NodeList L;
	int i=0,n;
	for(i=0;i<10;i++)
	{
		e[i].keynum=i;
		f[i].keynum=i;
		f[i].next=NULL;
		e[i].next=NULL;
	}
	L=InitNodelist(L);
	L=CreateNodelist(L,Randnum);
	n=High(Randnum);
	time_start=clock();
	for(i=0;i<n;i++)
	{
		L=Distribute(L,f,e,i);
		L=Collect(L,f,e);
	}
	time_over=clock();
	output(L);
	return (double)(time_over-time_start)/CLOCKS_PER_SEC;
}

int main()
{   
    double m;
    int b[20]={52,14,49,53,6,74,10,25,64,91,87,10,23,54,100,56,97,14,51,20};
    m=RadixSort(b);
	return 0;
} 
