#include<stdio.h>
#include<malloc.h>
#include<stdlib.h>
#include<time.h>

typedef struct 
{
	int num;
	int arrivetime[3];
	int endtime[3];
}Customers;

void FileStorage(FILE *In)
{
	int arrivehour,arriveminute,arrivesecond;
	int servicehour,serviceminute,servicesecond;
	srand((unsigned)time(NULL));
	printf("����ж��ٸ��˿ͣ�\n"); 
}

 
