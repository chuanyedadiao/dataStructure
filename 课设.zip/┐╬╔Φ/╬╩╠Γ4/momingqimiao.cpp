#include<stdio.h>


int main()
{
	FILE *IN;
	bool a; 
	bool b=1;
	IN=fopen("111.dat","rb");
	fread(&a,1,1,IN);
	if(a==b)
	{
		printf("111");
	}
	else printf("%c\n",a);
	printf("%c",b);
	return 0;
}
